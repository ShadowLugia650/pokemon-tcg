def scott(item):
    for _ in range(3):
        item.player.hand.append(item.player.prompt_card_from_deck("issupporter", "isstadium"))
