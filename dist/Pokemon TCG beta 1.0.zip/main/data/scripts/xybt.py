def floatstone_added(target):
    target.extra_effects["freeretreat"] = 1
